<!-- ![](https://hubs.ly/Q02hxv9c0) -->

# Load Effect for Load Combination
- This plugin identifies intermediate values contributing to the final reslt, allowing users to understand how each load cas affects the final outcome.
## Details
### version 1.0.0
- Users can intuitively verify the contribution of load cases within combination values.
- The plugin effectively shows load coefficients, comparisons, and consierations, highlighting the most unfavorable and least impactful values.

