// Util
import { IsDevEnv } from './Utils';

// Kit
import { default as Kit } from './Kit';

export {
	IsDevEnv,
	Kit,
}

const Tools = {
	IsDevEnv,
	Kit,
};

export default Tools;