const devServerStatus: string = '';
export const isDevServerListening = () => devServerStatus === 'listening';