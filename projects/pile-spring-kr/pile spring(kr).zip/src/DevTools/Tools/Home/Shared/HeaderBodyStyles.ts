export const radiusPixel = '4px';
export const color = '#e9e9e9';
export const rowHeaderHeight = '28px';